let truckX; // posição do caminhão
let truckY = 300; // altura do caminhão
let deliveryComplete = false;

function setup() {
  createCanvas(800, 400);
  truckX = 50; // posição inicial do caminhão no campo
}

function draw() {
  background(220);

  // Desenhar o campo
  fill(34, 139, 34); // verde
  rect(0, 300, 400, 100); // área rural

  // Desenhar a cidade
  fill(150);
  rect(600, 250, 150, 150); // prédios
  fill(0);
  textSize(16);
  text('Cidade', 650, 230);

  // Desenhar o caminhão
  fill(255, 0, 0);
  rect(truckX, truckY, 50, 30); // corpo do caminhão
  fill(0);
  ellipse(truckX + 10, truckY + 30, 10, 10); // roda esquerda
  ellipse(truckX + 40, truckY + 30, 10, 10); // roda direita

  // Movimento do caminhão
  if (truckX < 650) {
    truckX += 1; // velocidade do caminhão
  } else {
    deliveryComplete = true;
  }

  // Mostrar mensagem de entrega
  if (deliveryComplete) {
    fill(0);
    textSize(20);
    text('Entrega concluída!', 350, 50);
  }
}